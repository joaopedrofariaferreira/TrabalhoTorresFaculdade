﻿
namespace Trabalho_Marcelo_1
{
    partial class Imagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pctrBxAbrirImagens = new System.Windows.Forms.PictureBox();
            this.bttnImagem1 = new System.Windows.Forms.Button();
            this.bttnImagem2 = new System.Windows.Forms.Button();
            this.bttnImagem3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pctrBxAbrirImagens)).BeginInit();
            this.SuspendLayout();
            // 
            // pctrBxAbrirImagens
            // 
            this.pctrBxAbrirImagens.Location = new System.Drawing.Point(25, 23);
            this.pctrBxAbrirImagens.Name = "pctrBxAbrirImagens";
            this.pctrBxAbrirImagens.Size = new System.Drawing.Size(250, 250);
            this.pctrBxAbrirImagens.TabIndex = 0;
            this.pctrBxAbrirImagens.TabStop = false;
            // 
            // bttnImagem1
            // 
            this.bttnImagem1.Location = new System.Drawing.Point(670, 77);
            this.bttnImagem1.Name = "bttnImagem1";
            this.bttnImagem1.Size = new System.Drawing.Size(75, 23);
            this.bttnImagem1.TabIndex = 1;
            this.bttnImagem1.Text = "Imagem1";
            this.bttnImagem1.UseVisualStyleBackColor = true;
            this.bttnImagem1.Click += new System.EventHandler(this.bttnImagem1_Click);
            // 
            // bttnImagem2
            // 
            this.bttnImagem2.Location = new System.Drawing.Point(670, 106);
            this.bttnImagem2.Name = "bttnImagem2";
            this.bttnImagem2.Size = new System.Drawing.Size(75, 23);
            this.bttnImagem2.TabIndex = 2;
            this.bttnImagem2.Text = "Imagem 2";
            this.bttnImagem2.UseVisualStyleBackColor = true;
            this.bttnImagem2.Click += new System.EventHandler(this.bttnImagem2_Click);
            // 
            // bttnImagem3
            // 
            this.bttnImagem3.Location = new System.Drawing.Point(670, 135);
            this.bttnImagem3.Name = "bttnImagem3";
            this.bttnImagem3.Size = new System.Drawing.Size(75, 23);
            this.bttnImagem3.TabIndex = 3;
            this.bttnImagem3.Text = "Imagen 3";
            this.bttnImagem3.UseVisualStyleBackColor = true;
            this.bttnImagem3.Click += new System.EventHandler(this.bttnImagem3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(667, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Adicinar Imagens";
            // 
            // Imagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttnImagem3);
            this.Controls.Add(this.bttnImagem2);
            this.Controls.Add(this.bttnImagem1);
            this.Controls.Add(this.pctrBxAbrirImagens);
            this.Name = "Imagem";
            this.Text = "Imagem";
            ((System.ComponentModel.ISupportInitialize)(this.pctrBxAbrirImagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bttnImagem1;
        private System.Windows.Forms.Button bttnImagem2;
        private System.Windows.Forms.Button bttnImagem3;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox pctrBxAbrirImagens;
    }
}