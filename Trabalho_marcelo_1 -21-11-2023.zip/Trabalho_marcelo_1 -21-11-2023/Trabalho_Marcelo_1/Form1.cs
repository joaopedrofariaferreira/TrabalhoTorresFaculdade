﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_Marcelo_1
{
    public partial class Form1 : Form
    {
        Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        int zoom = 100;

        bool alterado;
        public Form1()
        {
            InitializeComponent();
            this.Location = new Point(Int32.Parse(config.AppSettings.Settings["windowPositionX"].Value), Int32.Parse(config.AppSettings.Settings["windowPositionY"].Value));
            this.Size = new Size(Int32.Parse(config.AppSettings.Settings["sizeW"].Value), Int32.Parse(config.AppSettings.Settings["sizeH"].Value));
            barraDeStatusToolStripMenuItem.Checked = true;
            this.atualizaPosicao();
        }

        private void atualizaPosicao()
        {
            int linha = rchTxtBxConteudo.GetLineFromCharIndex(rchTxtBxConteudo.SelectionStart);
            int coluna = rchTxtBxConteudo.SelectionStart - rchTxtBxConteudo.GetFirstCharIndexFromLine(linha);
            tlStrpSttsLblPosicionamento.Text = "Ln: " + linha.ToString() + ", Cl: " + coluna.ToString();
        }


        private void rchTxtBxConteudo_TextChanged(object sender, EventArgs e)
        {
            //toda vez que houver mudança no texto
            this.atualizaPosicao();
            alterado = true;
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!alterado)
            {
                this.abrir();
            }

            else
            {
                DialogResult clicar = MessageBox.Show("Seu arquivo foi alterado. Deseja salvar?", "WordPad",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (clicar == DialogResult.Yes)
                {
                    if(this.Text != "")
                    {
                        this.salvar(this.Text);
                    }
                    else
                    {
                        this.salvarComo();
                    }
                }
                else
                {
                    this.abrir();
                }
            }
        }

        private void salvarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.salvar(this.Text);
        }

        private void limparTelaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DialogResult clicar = MessageBox.Show("Realmente deseja limpar a tela?", "WordPad",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (clicar == DialogResult.Yes)
            {
                this.Text = "";
                rchTxtBxConteudo.Text = "";
            }

            
        }

        private void salvarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.salvarComo();
        }

        private void abrir()
        {
            if (opnFlDlgAbrir.ShowDialog() == DialogResult.OK)
            {
                this.Text = opnFlDlgAbrir.FileName;
                using (StreamReader leitor = new StreamReader(opnFlDlgAbrir.OpenFile()))
                {
                    rchTxtBxConteudo.Rtf = leitor.ReadToEnd();
                    alterado = false;
                }
                this.Text = opnFlDlgAbrir.FileName;
            }
        }

        private void salvar(String texto)
        {
            if(texto != "")
            {
                StreamWriter buffer = new StreamWriter(texto);
                buffer.Write(rchTxtBxConteudo.Rtf);
                buffer.Close();
                this.Text = texto;
                alterado = false;
            }
            else
            {
                MessageBox.Show("Nome do arquivo inválido!", "Salvar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void salvarComo()
        {
            if(svFlDlgSalvar.ShowDialog() == DialogResult.OK)
            {
                this.salvar(svFlDlgSalvar.FileName);
            }
        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!alterado)
            {
                this.Text = "";
                rchTxtBxConteudo.Text = "";
            }

            else
            {
                DialogResult clicar = MessageBox.Show("Seu arquivo foi alterado. Deseja salvar?", "WordPad",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (clicar == DialogResult.Yes)
                {
                    if (this.Text != "")
                    {
                        this.salvar(this.Text);
                    }
                    else
                    {
                        this.salvarComo();
                    }
                }
                else
                {
                    this.Text = "";
                    rchTxtBxConteudo.Text = "";
                }
            }

        }

        private void desfazerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Undo();
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(rchTxtBxConteudo.SelectedRtf != "")
            {
                //Clipboard.SetDataObject(rchTxtBxConteudo.SelectedRtf);
                Clipboard.SetDataObject(rchTxtBxConteudo.SelectedText);

                rchTxtBxConteudo.SelectedRtf = "";
            }
        }

        private void excluirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rchTxtBxConteudo.SelectedRtf != "")
            {
                Clipboard.SetDataObject(rchTxtBxConteudo.SelectedRtf);
            }
        }

        private void buscarComOBingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text))
            {
                rchTxtBxConteudo.SelectedText = (String)Clipboard.GetData(DataFormats.Text);
            }

        }

        private void localizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rchTxtBxConteudo.SelectedRtf != "")
            {
                rchTxtBxConteudo.SelectedRtf = "";
            }

        }

        private void selecionarTudoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.SelectAll();
        }

        private void horadataToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.SelectedText = System.Environment.NewLine + DateTime.Now;
        }

        private void quebraAutomaticaDeLinhaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(quebraAutomaticaDeLinhaToolStripMenuItem.CheckState == CheckState.Checked)
            {
                quebraAutomaticaDeLinhaToolStripMenuItem.CheckState = CheckState.Unchecked;
                rchTxtBxConteudo.WordWrap = false;
            }
            else
            {
                quebraAutomaticaDeLinhaToolStripMenuItem.CheckState = CheckState.Checked;
                rchTxtBxConteudo.WordWrap = true;
            }
        }

        private void localizarAnteriorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rchTxtBxConteudo.SelectedRtf!="")
            {
                String texto = rchTxtBxConteudo.SelectedText;
                texto.Replace(' ','+');
                System.Diagnostics.Process.Start("microsoft-edge:http://www.bing.com/search?q=" + texto);
            }
            else
            {
                MessageBox.Show("É necessário selecionar um termo para pesquisar.", "Buscar com o Bing", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void configuraçãoDePáginasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pgStpDlgConfigurarPagina.ShowDialog();
        }

        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            prntDlgImprimir.ShowDialog();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void novaJanelaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
        }

        private void fonteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(fntDlgFonte.ShowDialog() == DialogResult.OK)
            {
                rchTxtBxConteudo.SelectionFont = fntDlgFonte.Font;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            config.AppSettings.Settings["windowPositionX"].Value = this.Location.X.ToString();
            config.AppSettings.Settings["windowPositionY"].Value = this.Location.Y.ToString();
            config.AppSettings.Settings["sizeW"].Value = this.Size.Width.ToString();
            config.AppSettings.Settings["sizeH"].Value = this.Size.Height.ToString();
            config.Save(ConfigurationSaveMode.Modified);
        }

        private void barraDeStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            barraDeStatusToolStripMenuItem.Checked = !barraDeStatusToolStripMenuItem.Checked;
            sttsStrpInformacoes.Visible = !sttsStrpInformacoes.Visible;
        }

        private void atualizaZoom()
        {
            tlStrpSttsLblZoom.Text = this.zoom.ToString() + "%";
        }

        private void ampliarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.zoom++;
            rchTxtBxConteudo.Font = new Font(rchTxtBxConteudo.Font.FontFamily, rchTxtBxConteudo.Font.Size + 1, rchTxtBxConteudo.Font.Style);
            this.atualizaZoom();
        }

        private void reduzirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.zoom--;
            rchTxtBxConteudo.Font = new Font(rchTxtBxConteudo.Font.FontFamily, rchTxtBxConteudo.Font.Size - 1, rchTxtBxConteudo.Font.Style);
            this.atualizaZoom();
        }

        private void reajustarZoomPadrãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.zoom = 100;
            rchTxtBxConteudo.Font = new Font(rchTxtBxConteudo.Font.FontFamily, 12, rchTxtBxConteudo.Font.Style);
            this.atualizaZoom();
        }

        private void corToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (clrDlgCor.ShowDialog() == DialogResult.OK)
            {
                rchTxtBxConteudo.SelectionColor = clrDlgCor.Color;
            }
        }

        private void horadataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Substituir frm = new Substituir();
            frm.txtBxLocalizar.Text = rchTxtBxConteudo.SelectedText;
            frm.Show(this);
        }

        private void substituirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Localizar frm = new Localizar();
            frm.txtBxLocalizar.Text = rchTxtBxConteudo.SelectedText;
            frm.Show(this);
        }

        private void abrirImagensToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Imagem frm = new Imagem();
            frm.Show();
        }
    }
}
