﻿
namespace Trabalho_Marcelo_1
{
    partial class Localizar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtBxLocalizar = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.chckBxCaseSensitive = new System.Windows.Forms.CheckBox();
            this.chckBxPalavraInteira = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Localizar:";
            // 
            // txtBxLocalizar
            // 
            this.txtBxLocalizar.Location = new System.Drawing.Point(70, 6);
            this.txtBxLocalizar.Name = "txtBxLocalizar";
            this.txtBxLocalizar.Size = new System.Drawing.Size(126, 20);
            this.txtBxLocalizar.TabIndex = 1;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(202, 9);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 2;
            this.btnBuscar.Text = "Localizar Todos:";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(202, 39);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 3;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // chckBxCaseSensitive
            // 
            this.chckBxCaseSensitive.AutoSize = true;
            this.chckBxCaseSensitive.Location = new System.Drawing.Point(0, 38);
            this.chckBxCaseSensitive.Name = "chckBxCaseSensitive";
            this.chckBxCaseSensitive.Size = new System.Drawing.Size(196, 17);
            this.chckBxCaseSensitive.TabIndex = 4;
            this.chckBxCaseSensitive.Text = "Diferenciar maiúsculas e minúsculas";
            this.chckBxCaseSensitive.UseVisualStyleBackColor = true;
            // 
            // chckBxPalavraInteira
            // 
            this.chckBxPalavraInteira.AutoSize = true;
            this.chckBxPalavraInteira.Location = new System.Drawing.Point(0, 62);
            this.chckBxPalavraInteira.Name = "chckBxPalavraInteira";
            this.chckBxPalavraInteira.Size = new System.Drawing.Size(135, 17);
            this.chckBxPalavraInteira.TabIndex = 5;
            this.chckBxPalavraInteira.Text = "Coincidir palavra inteira";
            this.chckBxPalavraInteira.UseVisualStyleBackColor = true;
            // 
            // Localizar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 124);
            this.Controls.Add(this.chckBxPalavraInteira);
            this.Controls.Add(this.chckBxCaseSensitive);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtBxLocalizar);
            this.Controls.Add(this.label1);
            this.Name = "Localizar";
            this.Text = "Localizar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtBxLocalizar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.CheckBox chckBxCaseSensitive;
        private System.Windows.Forms.CheckBox chckBxPalavraInteira;
    }
}