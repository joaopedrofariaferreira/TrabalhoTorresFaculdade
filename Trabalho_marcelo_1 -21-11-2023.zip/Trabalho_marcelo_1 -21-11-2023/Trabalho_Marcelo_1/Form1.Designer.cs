﻿
namespace Trabalho_Marcelo_1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnStrpPrincipal = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarComoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçãoDePáginasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novaJanelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desfazerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buscarComOBingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localizarPróximoToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.localizarAnteriorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.substituirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irParaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selecionarTudoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horadataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irParaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.selecionarTudoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.horadataToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.formatarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quebraAutomaticaDeLinhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fonteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.corToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ampliarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reduzirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reajustarZoomPadrãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barraDeStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limparTelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirImagens = new System.Windows.Forms.ToolStripMenuItem();
            this.sttsStrpInformacoes = new System.Windows.Forms.StatusStrip();
            this.tlStrpSttsLblCodficação = new System.Windows.Forms.ToolStripStatusLabel();
            this.tlStrpSttsLblFormato = new System.Windows.Forms.ToolStripStatusLabel();
            this.tlStrpSttsLblZoom = new System.Windows.Forms.ToolStripStatusLabel();
            this.tlStrpSttsLblPosicionamento = new System.Windows.Forms.ToolStripStatusLabel();
            this.rchTxtBxConteudo = new System.Windows.Forms.RichTextBox();
            this.opnFlDlgAbrir = new System.Windows.Forms.OpenFileDialog();
            this.svFlDlgSalvar = new System.Windows.Forms.SaveFileDialog();
            this.prntDlgImprimir = new System.Windows.Forms.PrintDialog();
            this.prntDcmntConteudo = new System.Drawing.Printing.PrintDocument();
            this.pgStpDlgConfigurarPagina = new System.Windows.Forms.PageSetupDialog();
            this.fntDlgFonte = new System.Windows.Forms.FontDialog();
            this.clrDlgCor = new System.Windows.Forms.ColorDialog();
            this.mnStrpPrincipal.SuspendLayout();
            this.sttsStrpInformacoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnStrpPrincipal
            // 
            this.mnStrpPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.editarToolStripMenuItem,
            this.formatarToolStripMenuItem,
            this.exibirToolStripMenuItem,
            this.limparTelaToolStripMenuItem,
            this.abrirImagens});
            this.mnStrpPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnStrpPrincipal.Name = "mnStrpPrincipal";
            this.mnStrpPrincipal.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mnStrpPrincipal.Size = new System.Drawing.Size(551, 24);
            this.mnStrpPrincipal.TabIndex = 0;
            this.mnStrpPrincipal.Text = "Abrir Imagens";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoToolStripMenuItem,
            this.abrirToolStripMenuItem,
            this.salvarToolStripMenuItem,
            this.salvarComoToolStripMenuItem,
            this.toolStripMenuItem1,
            this.imprimirToolStripMenuItem,
            this.configuraçãoDePáginasToolStripMenuItem,
            this.toolStripMenuItem2,
            this.sairToolStripMenuItem,
            this.novaJanelaToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "&Arquivo";
            // 
            // novoToolStripMenuItem
            // 
            this.novoToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_Novo1;
            this.novoToolStripMenuItem.Name = "novoToolStripMenuItem";
            this.novoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.novoToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.novoToolStripMenuItem.Text = "Novo";
            this.novoToolStripMenuItem.Click += new System.EventHandler(this.novoToolStripMenuItem_Click);
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_Abrir1;
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            this.abrirToolStripMenuItem.Click += new System.EventHandler(this.abrirToolStripMenuItem_Click);
            // 
            // salvarToolStripMenuItem
            // 
            this.salvarToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_disquete_salvar1;
            this.salvarToolStripMenuItem.Name = "salvarToolStripMenuItem";
            this.salvarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.salvarToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.salvarToolStripMenuItem.Text = "Salvar";
            this.salvarToolStripMenuItem.Click += new System.EventHandler(this.salvarToolStripMenuItem_Click);
            // 
            // salvarComoToolStripMenuItem
            // 
            this.salvarComoToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_disquete_salvar_como1;
            this.salvarComoToolStripMenuItem.Name = "salvarComoToolStripMenuItem";
            this.salvarComoToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.salvarComoToolStripMenuItem.Text = "Salvar como";
            this.salvarComoToolStripMenuItem.Click += new System.EventHandler(this.salvarComoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(203, 6);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_imprimir1;
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // configuraçãoDePáginasToolStripMenuItem
            // 
            this.configuraçãoDePáginasToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_configurarPagina1;
            this.configuraçãoDePáginasToolStripMenuItem.Name = "configuraçãoDePáginasToolStripMenuItem";
            this.configuraçãoDePáginasToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.configuraçãoDePáginasToolStripMenuItem.Text = "Configuração de páginas";
            this.configuraçãoDePáginasToolStripMenuItem.Click += new System.EventHandler(this.configuraçãoDePáginasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(203, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_sair;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // novaJanelaToolStripMenuItem
            // 
            this.novaJanelaToolStripMenuItem.Name = "novaJanelaToolStripMenuItem";
            this.novaJanelaToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.novaJanelaToolStripMenuItem.Text = "Nova Janela";
            this.novaJanelaToolStripMenuItem.Click += new System.EventHandler(this.novaJanelaToolStripMenuItem_Click);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.desfazerToolStripMenuItem,
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem,
            this.excluirToolStripMenuItem,
            this.buscarComOBingToolStripMenuItem,
            this.localizarToolStripMenuItem,
            this.localizarPróximoToolStripMenuItem,
            this.localizarAnteriorToolStripMenuItem,
            this.substituirToolStripMenuItem,
            this.irParaToolStripMenuItem,
            this.selecionarTudoToolStripMenuItem,
            this.horadataToolStripMenuItem,
            this.irParaToolStripMenuItem1,
            this.toolStripMenuItem3,
            this.selecionarTudoToolStripMenuItem1,
            this.horadataToolStripMenuItem1});
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.editarToolStripMenuItem.Text = "&Editar";
            // 
            // desfazerToolStripMenuItem
            // 
            this.desfazerToolStripMenuItem.Name = "desfazerToolStripMenuItem";
            this.desfazerToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.desfazerToolStripMenuItem.Text = "Desfazer";
            this.desfazerToolStripMenuItem.Click += new System.EventHandler(this.desfazerToolStripMenuItem_Click);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(177, 6);
            // 
            // colarToolStripMenuItem
            // 
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            this.colarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.colarToolStripMenuItem.Text = "Recortar";
            this.colarToolStripMenuItem.Click += new System.EventHandler(this.colarToolStripMenuItem_Click);
            // 
            // excluirToolStripMenuItem
            // 
            this.excluirToolStripMenuItem.Name = "excluirToolStripMenuItem";
            this.excluirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.excluirToolStripMenuItem.Text = "Copiar";
            this.excluirToolStripMenuItem.Click += new System.EventHandler(this.excluirToolStripMenuItem_Click);
            // 
            // buscarComOBingToolStripMenuItem
            // 
            this.buscarComOBingToolStripMenuItem.Name = "buscarComOBingToolStripMenuItem";
            this.buscarComOBingToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.buscarComOBingToolStripMenuItem.Text = "Colar";
            this.buscarComOBingToolStripMenuItem.Click += new System.EventHandler(this.buscarComOBingToolStripMenuItem_Click);
            // 
            // localizarToolStripMenuItem
            // 
            this.localizarToolStripMenuItem.Name = "localizarToolStripMenuItem";
            this.localizarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.localizarToolStripMenuItem.Text = "Excluir";
            this.localizarToolStripMenuItem.Click += new System.EventHandler(this.localizarToolStripMenuItem_Click);
            // 
            // localizarPróximoToolStripMenuItem
            // 
            this.localizarPróximoToolStripMenuItem.Name = "localizarPróximoToolStripMenuItem";
            this.localizarPróximoToolStripMenuItem.Size = new System.Drawing.Size(177, 6);
            // 
            // localizarAnteriorToolStripMenuItem
            // 
            this.localizarAnteriorToolStripMenuItem.Name = "localizarAnteriorToolStripMenuItem";
            this.localizarAnteriorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.localizarAnteriorToolStripMenuItem.Text = "Buscar com Bing...";
            this.localizarAnteriorToolStripMenuItem.Click += new System.EventHandler(this.localizarAnteriorToolStripMenuItem_Click);
            // 
            // substituirToolStripMenuItem
            // 
            this.substituirToolStripMenuItem.Name = "substituirToolStripMenuItem";
            this.substituirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.substituirToolStripMenuItem.Text = "Localizar....";
            this.substituirToolStripMenuItem.Click += new System.EventHandler(this.substituirToolStripMenuItem_Click);
            // 
            // irParaToolStripMenuItem
            // 
            this.irParaToolStripMenuItem.Name = "irParaToolStripMenuItem";
            this.irParaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.irParaToolStripMenuItem.Text = "Localizar próxima";
            // 
            // selecionarTudoToolStripMenuItem
            // 
            this.selecionarTudoToolStripMenuItem.Name = "selecionarTudoToolStripMenuItem";
            this.selecionarTudoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.selecionarTudoToolStripMenuItem.Text = "Localizar Anterior";
            // 
            // horadataToolStripMenuItem
            // 
            this.horadataToolStripMenuItem.Name = "horadataToolStripMenuItem";
            this.horadataToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.horadataToolStripMenuItem.Text = "Substituir...";
            this.horadataToolStripMenuItem.Click += new System.EventHandler(this.horadataToolStripMenuItem_Click);
            // 
            // irParaToolStripMenuItem1
            // 
            this.irParaToolStripMenuItem1.Name = "irParaToolStripMenuItem1";
            this.irParaToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.irParaToolStripMenuItem1.Text = "Ir para....";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(177, 6);
            // 
            // selecionarTudoToolStripMenuItem1
            // 
            this.selecionarTudoToolStripMenuItem1.Name = "selecionarTudoToolStripMenuItem1";
            this.selecionarTudoToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.selecionarTudoToolStripMenuItem1.Text = "Selecionar Tudo";
            this.selecionarTudoToolStripMenuItem1.Click += new System.EventHandler(this.selecionarTudoToolStripMenuItem1_Click);
            // 
            // horadataToolStripMenuItem1
            // 
            this.horadataToolStripMenuItem1.Name = "horadataToolStripMenuItem1";
            this.horadataToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.horadataToolStripMenuItem1.Text = "Hora/data";
            this.horadataToolStripMenuItem1.Click += new System.EventHandler(this.horadataToolStripMenuItem1_Click);
            // 
            // formatarToolStripMenuItem
            // 
            this.formatarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quebraAutomaticaDeLinhaToolStripMenuItem,
            this.fonteToolStripMenuItem,
            this.corToolStripMenuItem});
            this.formatarToolStripMenuItem.Name = "formatarToolStripMenuItem";
            this.formatarToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.formatarToolStripMenuItem.Text = "&Formatar";
            // 
            // quebraAutomaticaDeLinhaToolStripMenuItem
            // 
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Name = "quebraAutomaticaDeLinhaToolStripMenuItem";
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Text = "Quebra automatica de linha";
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Click += new System.EventHandler(this.quebraAutomaticaDeLinhaToolStripMenuItem_Click);
            // 
            // fonteToolStripMenuItem
            // 
            this.fonteToolStripMenuItem.Name = "fonteToolStripMenuItem";
            this.fonteToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.fonteToolStripMenuItem.Text = "Fonte";
            this.fonteToolStripMenuItem.Click += new System.EventHandler(this.fonteToolStripMenuItem_Click);
            // 
            // corToolStripMenuItem
            // 
            this.corToolStripMenuItem.Name = "corToolStripMenuItem";
            this.corToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.corToolStripMenuItem.Text = "Cor";
            this.corToolStripMenuItem.Click += new System.EventHandler(this.corToolStripMenuItem_Click);
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zoomToolStripMenuItem,
            this.barraDeStatusToolStripMenuItem});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // zoomToolStripMenuItem
            // 
            this.zoomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ampliarToolStripMenuItem,
            this.reduzirToolStripMenuItem,
            this.reajustarZoomPadrãoToolStripMenuItem});
            this.zoomToolStripMenuItem.Name = "zoomToolStripMenuItem";
            this.zoomToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.zoomToolStripMenuItem.Text = "Zoom";
            // 
            // ampliarToolStripMenuItem
            // 
            this.ampliarToolStripMenuItem.Name = "ampliarToolStripMenuItem";
            this.ampliarToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.ampliarToolStripMenuItem.Text = "Ampliar";
            this.ampliarToolStripMenuItem.Click += new System.EventHandler(this.ampliarToolStripMenuItem_Click);
            // 
            // reduzirToolStripMenuItem
            // 
            this.reduzirToolStripMenuItem.Name = "reduzirToolStripMenuItem";
            this.reduzirToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.reduzirToolStripMenuItem.Text = "Reduzir";
            this.reduzirToolStripMenuItem.Click += new System.EventHandler(this.reduzirToolStripMenuItem_Click);
            // 
            // reajustarZoomPadrãoToolStripMenuItem
            // 
            this.reajustarZoomPadrãoToolStripMenuItem.Name = "reajustarZoomPadrãoToolStripMenuItem";
            this.reajustarZoomPadrãoToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.reajustarZoomPadrãoToolStripMenuItem.Text = "Reajustar Zoom Padrão";
            this.reajustarZoomPadrãoToolStripMenuItem.Click += new System.EventHandler(this.reajustarZoomPadrãoToolStripMenuItem_Click);
            // 
            // barraDeStatusToolStripMenuItem
            // 
            this.barraDeStatusToolStripMenuItem.Name = "barraDeStatusToolStripMenuItem";
            this.barraDeStatusToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.barraDeStatusToolStripMenuItem.Text = "Barra de Status";
            this.barraDeStatusToolStripMenuItem.Click += new System.EventHandler(this.barraDeStatusToolStripMenuItem_Click);
            // 
            // limparTelaToolStripMenuItem
            // 
            this.limparTelaToolStripMenuItem.Name = "limparTelaToolStripMenuItem";
            this.limparTelaToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.limparTelaToolStripMenuItem.Text = "Limpar Tela";
            this.limparTelaToolStripMenuItem.Click += new System.EventHandler(this.limparTelaToolStripMenuItem_Click);
            // 
            // abrirImagens
            // 
            this.abrirImagens.Name = "abrirImagens";
            this.abrirImagens.Size = new System.Drawing.Size(93, 20);
            this.abrirImagens.Text = "Abrir Imagens";
            this.abrirImagens.Click += new System.EventHandler(this.abrirImagensToolStripMenuItem_Click);
            // 
            // sttsStrpInformacoes
            // 
            this.sttsStrpInformacoes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlStrpSttsLblCodficação,
            this.tlStrpSttsLblFormato,
            this.tlStrpSttsLblZoom,
            this.tlStrpSttsLblPosicionamento});
            this.sttsStrpInformacoes.Location = new System.Drawing.Point(0, 426);
            this.sttsStrpInformacoes.Name = "sttsStrpInformacoes";
            this.sttsStrpInformacoes.Size = new System.Drawing.Size(551, 24);
            this.sttsStrpInformacoes.TabIndex = 1;
            this.sttsStrpInformacoes.Text = "statusStrip1";
            // 
            // tlStrpSttsLblCodficação
            // 
            this.tlStrpSttsLblCodficação.Name = "tlStrpSttsLblCodficação";
            this.tlStrpSttsLblCodficação.Size = new System.Drawing.Size(38, 19);
            this.tlStrpSttsLblCodficação.Text = "UTF-8";
            // 
            // tlStrpSttsLblFormato
            // 
            this.tlStrpSttsLblFormato.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.tlStrpSttsLblFormato.Name = "tlStrpSttsLblFormato";
            this.tlStrpSttsLblFormato.Size = new System.Drawing.Size(103, 19);
            this.tlStrpSttsLblFormato.Text = "Windows (CR-LF)";
            // 
            // tlStrpSttsLblZoom
            // 
            this.tlStrpSttsLblZoom.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.tlStrpSttsLblZoom.Name = "tlStrpSttsLblZoom";
            this.tlStrpSttsLblZoom.Size = new System.Drawing.Size(39, 19);
            this.tlStrpSttsLblZoom.Text = "100%";
            // 
            // tlStrpSttsLblPosicionamento
            // 
            this.tlStrpSttsLblPosicionamento.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.tlStrpSttsLblPosicionamento.Name = "tlStrpSttsLblPosicionamento";
            this.tlStrpSttsLblPosicionamento.Size = new System.Drawing.Size(60, 19);
            this.tlStrpSttsLblPosicionamento.Text = ":Lin: , Col";
            // 
            // rchTxtBxConteudo
            // 
            this.rchTxtBxConteudo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBxConteudo.Location = new System.Drawing.Point(0, 24);
            this.rchTxtBxConteudo.Name = "rchTxtBxConteudo";
            this.rchTxtBxConteudo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rchTxtBxConteudo.Size = new System.Drawing.Size(551, 426);
            this.rchTxtBxConteudo.TabIndex = 2;
            this.rchTxtBxConteudo.Text = "";
            this.rchTxtBxConteudo.TextChanged += new System.EventHandler(this.rchTxtBxConteudo_TextChanged);
            // 
            // opnFlDlgAbrir
            // 
            this.opnFlDlgAbrir.Filter = "Documentos de Texto (*.rtf)|*.rtf|Arquivo de texto (*.txt)|*.txt|Todos os Arquivo" +
    "s (*.*)|*.*";
            this.opnFlDlgAbrir.InitialDirectory = "C:\\Users\\Cassia\\Documents\\Visual Studio 2019\\Trabalho_marcelo_1\\Arquivo";
            this.opnFlDlgAbrir.Title = "Abrir arquivo";
            // 
            // svFlDlgSalvar
            // 
            this.svFlDlgSalvar.Filter = "Documentos de Texto (*.rtf)|*.rtf|Arquivo de texto (*.txt)|*.txt|Todos os Arquivo" +
    "s (*.*)|*.*";
            // 
            // prntDlgImprimir
            // 
            this.prntDlgImprimir.Document = this.prntDcmntConteudo;
            this.prntDlgImprimir.UseEXDialog = true;
            // 
            // pgStpDlgConfigurarPagina
            // 
            this.pgStpDlgConfigurarPagina.Document = this.prntDcmntConteudo;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 450);
            this.Controls.Add(this.sttsStrpInformacoes);
            this.Controls.Add(this.rchTxtBxConteudo);
            this.Controls.Add(this.mnStrpPrincipal);
            this.KeyPreview = true;
            this.MainMenuStrip = this.mnStrpPrincipal;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.mnStrpPrincipal.ResumeLayout(false);
            this.mnStrpPrincipal.PerformLayout();
            this.sttsStrpInformacoes.ResumeLayout(false);
            this.sttsStrpInformacoes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnStrpPrincipal;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.StatusStrip sttsStrpInformacoes;
        private System.Windows.Forms.ToolStripMenuItem novoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarComoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraçãoDePáginasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desfazerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buscarComOBingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localizarAnteriorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem substituirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irParaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horadataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quebraAutomaticaDeLinhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fonteToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog opnFlDlgAbrir;
        private System.Windows.Forms.SaveFileDialog svFlDlgSalvar;
        private System.Windows.Forms.ToolStripMenuItem limparTelaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator localizarPróximoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irParaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem horadataToolStripMenuItem1;
        private System.Windows.Forms.PrintDialog prntDlgImprimir;
        private System.Drawing.Printing.PrintDocument prntDcmntConteudo;
        private System.Windows.Forms.PageSetupDialog pgStpDlgConfigurarPagina;
        private System.Windows.Forms.ToolStripMenuItem novaJanelaToolStripMenuItem;
        private System.Windows.Forms.FontDialog fntDlgFonte;
        private System.Windows.Forms.ToolStripStatusLabel tlStrpSttsLblCodficação;
        private System.Windows.Forms.ToolStripStatusLabel tlStrpSttsLblFormato;
        private System.Windows.Forms.ToolStripStatusLabel tlStrpSttsLblZoom;
        private System.Windows.Forms.ToolStripStatusLabel tlStrpSttsLblPosicionamento;
        private System.Windows.Forms.ToolStripMenuItem zoomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ampliarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reduzirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reajustarZoomPadrãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem barraDeStatusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem corToolStripMenuItem;
        private System.Windows.Forms.ColorDialog clrDlgCor;
        public System.Windows.Forms.RichTextBox rchTxtBxConteudo;
        public System.Windows.Forms.ToolStripMenuItem abrirImagens;
    }
}

