﻿
namespace Trabalho_Marcelo_1
{
    partial class Substituir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtBxLocalizar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBxSubstituir = new System.Windows.Forms.TextBox();
            this.btnSubstitui = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Localizar: ";
            // 
            // txtBxLocalizar
            // 
            this.txtBxLocalizar.Location = new System.Drawing.Point(78, 10);
            this.txtBxLocalizar.Name = "txtBxLocalizar";
            this.txtBxLocalizar.Size = new System.Drawing.Size(211, 20);
            this.txtBxLocalizar.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Substituir por:";
            // 
            // txtBxSubstituir
            // 
            this.txtBxSubstituir.Location = new System.Drawing.Point(81, 39);
            this.txtBxSubstituir.Name = "txtBxSubstituir";
            this.txtBxSubstituir.Size = new System.Drawing.Size(211, 20);
            this.txtBxSubstituir.TabIndex = 3;
            // 
            // btnSubstitui
            // 
            this.btnSubstitui.Location = new System.Drawing.Point(311, 10);
            this.btnSubstitui.Name = "btnSubstitui";
            this.btnSubstitui.Size = new System.Drawing.Size(129, 23);
            this.btnSubstitui.TabIndex = 4;
            this.btnSubstitui.Text = "Substituir todos";
            this.btnSubstitui.UseVisualStyleBackColor = true;
            this.btnSubstitui.Click += new System.EventHandler(this.btnSubstitui_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(311, 39);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(129, 23);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // Substituir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 148);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnSubstitui);
            this.Controls.Add(this.txtBxSubstituir);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBxLocalizar);
            this.Controls.Add(this.label1);
            this.Name = "Substituir";
            this.Text = "Substituir";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSubstitui;
        private System.Windows.Forms.Button btnCancelar;
        public System.Windows.Forms.TextBox txtBxLocalizar;
        public System.Windows.Forms.TextBox txtBxSubstituir;
    }
}