﻿
namespace Trabalho_Marcelo_1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnStrpPrincipal = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarComoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçãoDePáginasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desfazerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buscarComOBingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localizarAnteriorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.substituirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irParaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selecionarTudoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horadataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quebraAutomaticaDeLinhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fonteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sttsStrpInformacoes = new System.Windows.Forms.StatusStrip();
            this.rchTxtBxConteudo = new System.Windows.Forms.RichTextBox();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.localizarPróximoToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.iiParaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selecionarTudoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.horadataToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnStrpPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnStrpPrincipal
            // 
            this.mnStrpPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.inicioToolStripMenuItem,
            this.editarToolStripMenuItem,
            this.formatarToolStripMenuItem,
            this.exibirToolStripMenuItem});
            this.mnStrpPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnStrpPrincipal.Name = "mnStrpPrincipal";
            this.mnStrpPrincipal.Size = new System.Drawing.Size(381, 24);
            this.mnStrpPrincipal.TabIndex = 0;
            this.mnStrpPrincipal.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoToolStripMenuItem,
            this.abrirToolStripMenuItem,
            this.salvarToolStripMenuItem,
            this.salvarComoToolStripMenuItem,
            this.toolStripMenuItem1,
            this.imprimirToolStripMenuItem,
            this.configuraçãoDePáginasToolStripMenuItem,
            this.toolStripMenuItem2,
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "&Arquivo";
            // 
            // novoToolStripMenuItem
            // 
            this.novoToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_Novo1;
            this.novoToolStripMenuItem.Name = "novoToolStripMenuItem";
            this.novoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.novoToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.novoToolStripMenuItem.Text = "Novo";
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_Abrir1;
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            // 
            // salvarToolStripMenuItem
            // 
            this.salvarToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_disquete_salvar1;
            this.salvarToolStripMenuItem.Name = "salvarToolStripMenuItem";
            this.salvarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.salvarToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.salvarToolStripMenuItem.Text = "Salvar";
            // 
            // salvarComoToolStripMenuItem
            // 
            this.salvarComoToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_disquete_salvar_como1;
            this.salvarComoToolStripMenuItem.Name = "salvarComoToolStripMenuItem";
            this.salvarComoToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.salvarComoToolStripMenuItem.Text = "Salvar como";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(203, 6);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_imprimir1;
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            // 
            // configuraçãoDePáginasToolStripMenuItem
            // 
            this.configuraçãoDePáginasToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_configurarPagina1;
            this.configuraçãoDePáginasToolStripMenuItem.Name = "configuraçãoDePáginasToolStripMenuItem";
            this.configuraçãoDePáginasToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.configuraçãoDePáginasToolStripMenuItem.Text = "Configuração de páginas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(203, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Image = global::Trabalho_Marcelo_1.Properties.Resources.foto_sair;
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.inicioToolStripMenuItem.Text = "&Inicio";
            this.inicioToolStripMenuItem.Click += new System.EventHandler(this.inicioToolStripMenuItem_Click);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.desfazerToolStripMenuItem,
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem,
            this.excluirToolStripMenuItem,
            this.buscarComOBingToolStripMenuItem,
            this.localizarToolStripMenuItem,
            this.localizarPróximoToolStripMenuItem,
            this.localizarAnteriorToolStripMenuItem,
            this.substituirToolStripMenuItem,
            this.irParaToolStripMenuItem,
            this.selecionarTudoToolStripMenuItem,
            this.horadataToolStripMenuItem,
            this.iiParaToolStripMenuItem,
            this.selecionarTudoToolStripMenuItem1,
            this.horadataToolStripMenuItem1});
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.editarToolStripMenuItem.Text = "&Editar";
            // 
            // desfazerToolStripMenuItem
            // 
            this.desfazerToolStripMenuItem.Name = "desfazerToolStripMenuItem";
            this.desfazerToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.desfazerToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.desfazerToolStripMenuItem.Text = "Desfazer";
            // 
            // colarToolStripMenuItem
            // 
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            this.colarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.colarToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.colarToolStripMenuItem.Text = "Recortar";
            // 
            // excluirToolStripMenuItem
            // 
            this.excluirToolStripMenuItem.Name = "excluirToolStripMenuItem";
            this.excluirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.excluirToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.excluirToolStripMenuItem.Text = "Copiar";
            // 
            // buscarComOBingToolStripMenuItem
            // 
            this.buscarComOBingToolStripMenuItem.Name = "buscarComOBingToolStripMenuItem";
            this.buscarComOBingToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.buscarComOBingToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.buscarComOBingToolStripMenuItem.Text = "Colar";
            // 
            // localizarToolStripMenuItem
            // 
            this.localizarToolStripMenuItem.Name = "localizarToolStripMenuItem";
            this.localizarToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.localizarToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.localizarToolStripMenuItem.Text = "Excluir";
            // 
            // localizarAnteriorToolStripMenuItem
            // 
            this.localizarAnteriorToolStripMenuItem.Name = "localizarAnteriorToolStripMenuItem";
            this.localizarAnteriorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.localizarAnteriorToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.localizarAnteriorToolStripMenuItem.Text = "Buscar com o Bing...";
            // 
            // substituirToolStripMenuItem
            // 
            this.substituirToolStripMenuItem.Name = "substituirToolStripMenuItem";
            this.substituirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.substituirToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.substituirToolStripMenuItem.Text = "Localizar..";
            // 
            // irParaToolStripMenuItem
            // 
            this.irParaToolStripMenuItem.Name = "irParaToolStripMenuItem";
            this.irParaToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.irParaToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.irParaToolStripMenuItem.Text = "Localizar Próxima";
            // 
            // selecionarTudoToolStripMenuItem
            // 
            this.selecionarTudoToolStripMenuItem.Name = "selecionarTudoToolStripMenuItem";
            this.selecionarTudoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F3)));
            this.selecionarTudoToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.selecionarTudoToolStripMenuItem.Text = "Localizar Anterior";
            // 
            // horadataToolStripMenuItem
            // 
            this.horadataToolStripMenuItem.Name = "horadataToolStripMenuItem";
            this.horadataToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.horadataToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.horadataToolStripMenuItem.Text = "Substituir...";
            // 
            // formatarToolStripMenuItem
            // 
            this.formatarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quebraAutomaticaDeLinhaToolStripMenuItem,
            this.fonteToolStripMenuItem});
            this.formatarToolStripMenuItem.Name = "formatarToolStripMenuItem";
            this.formatarToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.formatarToolStripMenuItem.Text = "&Formatar";
            // 
            // quebraAutomaticaDeLinhaToolStripMenuItem
            // 
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Name = "quebraAutomaticaDeLinhaToolStripMenuItem";
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.quebraAutomaticaDeLinhaToolStripMenuItem.Text = "Quebra automatica de linha";
            // 
            // fonteToolStripMenuItem
            // 
            this.fonteToolStripMenuItem.Name = "fonteToolStripMenuItem";
            this.fonteToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.fonteToolStripMenuItem.Text = "Fonte";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // sttsStrpInformacoes
            // 
            this.sttsStrpInformacoes.Location = new System.Drawing.Point(0, 428);
            this.sttsStrpInformacoes.Name = "sttsStrpInformacoes";
            this.sttsStrpInformacoes.Size = new System.Drawing.Size(381, 22);
            this.sttsStrpInformacoes.TabIndex = 1;
            this.sttsStrpInformacoes.Text = "statusStrip1";
            // 
            // rchTxtBxConteudo
            // 
            this.rchTxtBxConteudo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchTxtBxConteudo.Location = new System.Drawing.Point(0, 24);
            this.rchTxtBxConteudo.Name = "rchTxtBxConteudo";
            this.rchTxtBxConteudo.Size = new System.Drawing.Size(381, 404);
            this.rchTxtBxConteudo.TabIndex = 2;
            this.rchTxtBxConteudo.Text = "";
            this.rchTxtBxConteudo.TextChanged += new System.EventHandler(this.rchTxtBxConteudo_TextChanged);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(219, 6);
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // localizarPróximoToolStripMenuItem
            // 
            this.localizarPróximoToolStripMenuItem.Name = "localizarPróximoToolStripMenuItem";
            this.localizarPróximoToolStripMenuItem.Size = new System.Drawing.Size(219, 6);
            // 
            // iiParaToolStripMenuItem
            // 
            this.iiParaToolStripMenuItem.Name = "iiParaToolStripMenuItem";
            this.iiParaToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.iiParaToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.iiParaToolStripMenuItem.Text = "Ii para....";
            // 
            // selecionarTudoToolStripMenuItem1
            // 
            this.selecionarTudoToolStripMenuItem1.Name = "selecionarTudoToolStripMenuItem1";
            this.selecionarTudoToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selecionarTudoToolStripMenuItem1.Size = new System.Drawing.Size(222, 22);
            this.selecionarTudoToolStripMenuItem1.Text = "Selecionar tudo";
            // 
            // horadataToolStripMenuItem1
            // 
            this.horadataToolStripMenuItem1.Name = "horadataToolStripMenuItem1";
            this.horadataToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.horadataToolStripMenuItem1.Size = new System.Drawing.Size(222, 22);
            this.horadataToolStripMenuItem1.Text = "Hora/data";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 450);
            this.Controls.Add(this.rchTxtBxConteudo);
            this.Controls.Add(this.sttsStrpInformacoes);
            this.Controls.Add(this.mnStrpPrincipal);
            this.KeyPreview = true;
            this.MainMenuStrip = this.mnStrpPrincipal;
            this.Name = "Form1";
            this.Text = "Form1";
            this.mnStrpPrincipal.ResumeLayout(false);
            this.mnStrpPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnStrpPrincipal;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.StatusStrip sttsStrpInformacoes;
        private System.Windows.Forms.RichTextBox rchTxtBxConteudo;
        private System.Windows.Forms.ToolStripMenuItem novoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarComoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraçãoDePáginasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desfazerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buscarComOBingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localizarAnteriorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem substituirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irParaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horadataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quebraAutomaticaDeLinhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fonteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator localizarPróximoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iiParaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem horadataToolStripMenuItem1;
    }
}

