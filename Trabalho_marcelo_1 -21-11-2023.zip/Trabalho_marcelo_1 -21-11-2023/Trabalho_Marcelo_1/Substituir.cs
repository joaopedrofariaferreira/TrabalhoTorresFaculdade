﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_Marcelo_1
{
    public partial class Substituir : Form
    {
        public Substituir()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubstitui_Click(object sender, EventArgs e)
        {
            String busca = txtBxLocalizar.Text;
            String nova = txtBxSubstituir.Text;
            String texto = ((Form1)this.Owner).rchTxtBxConteudo.Text;

            ((Form1)this.Owner).rchTxtBxConteudo.Text = texto.Replace(busca, nova);

            this.Close();
        }
    }
}
